<?php

include("config.php");

if(isset($_POST['daftar'])){

    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $jk= $_POST['jk'];
    $pekerjaan= $_POST['pekerjaan'];

    $sql = "INSERT INTO pekerjaan (nama, alamat, jk, pekerjaan) VALUE
    ('$nama', '$alamat', '$jk', '$pekerjaan')";
    $query = mysqli_query($db, $sql);

    if( $query ) {
        header('Location: list.php?status=sukses');
    } else {
        header('Location: index.php?status=gagal');
    }

} else {
    die("Akses dilarang...");
}

?>