<?php include("config.php"); ?>


<!DOCTYPE html>
<html>
<head>
    <title>Data Mahasiswa</title>
    <link rel="stylesheet" href="style1.css">
</head>

<body>
    <header>
        <h2>Mahasiswa yang terdaftar</h2>
    </header>


    <br>

    <table border="1">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Jk</th>
            <th>Pekerjaan</th>

           
           
        </tr>
    </thead>
    <tbody>

        <?php
        $sql = "SELECT * FROM pekerjaan";
        $query = mysqli_query($db, $sql);

        while($siswa = mysqli_fetch_array($query)){
            echo  "<tr>";

            echo "<td>".$siswa['id']."</td>";
            echo "<td>".$siswa['nama']."</td>";
            echo "<td>".$siswa['alamat']."</td>";
            echo "<td>".$siswa['jk']."</td>";
            echo "<td>".$siswa['pekerjaan']."</td>";

        
            
        }
        ?>
    </tbody>
    </table>

    </body>
</html>
